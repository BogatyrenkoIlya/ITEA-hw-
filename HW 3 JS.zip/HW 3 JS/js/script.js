let styles = ['Джаз', 'Блюз'];
    styles.push('Рок-н-рол');
let index = Math.floor(styles.length / 2);
    styles[index] = 'Класика';
let removedElement = styles.shift();
    styles.unshift('Реп', 'Реггі');
let arrayContainer = document.getElementById('array');
    arrayContainer.innerText = styles.join(', ');
    console.log(removedElement);